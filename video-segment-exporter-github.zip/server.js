import crypto from "node:crypto";
import fs from "node:fs";
import fsp from "node:fs/promises";
import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDir = path.join(__dirname, "public");
const uploadsDir = path.join(__dirname, "work", "uploads");
const jobsDir = path.join(__dirname, "work", "jobs");
const outputRoot = path.join(__dirname, "outputs");

await fsp.mkdir(uploadsDir, { recursive: true });
await fsp.mkdir(jobsDir, { recursive: true });
await fsp.mkdir(outputRoot, { recursive: true });

const uploadedFiles = new Map();
const ffmpegPath = await findCommand("ffmpeg");
const zipPath = await findCommand("zip");
const exportFormats = new Set(["mp4", "mp3", "wav", "m4a", "aac", "flac", "ogg"]);

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || "/", `http://${req.headers.host}`);
    if (req.method === "POST" && url.pathname === "/api/upload") {
      await handleUpload(req, res);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/export") {
      await handleExport(req, res);
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/pick-folder") {
      await handlePickFolder(res);
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/health") {
      sendJson(res, { ffmpegReady: Boolean(ffmpegPath), zipReady: Boolean(zipPath) });
      return;
    }
    if (req.method === "GET" && url.pathname.startsWith("/downloads/")) {
      await serveFile(res, outputRoot, decodeURIComponent(url.pathname.replace("/downloads/", "")));
      return;
    }
    if (req.method === "GET") {
      const relative = url.pathname === "/" ? "index.html" : url.pathname.slice(1);
      await serveFile(res, publicDir, relative);
      return;
    }
    sendJson(res, { error: "不支持的操作" }, 405);
  } catch (error) {
    console.error(error);
    sendJson(res, { error: error.message || "处理失败" }, 500);
  }
});

const port = Number(process.env.PORT || 4173);
server.listen(port, () => {
  console.log(`视频剪切工具已启动：http://localhost:${port}`);
  console.log(ffmpegPath ? `FFmpeg：${ffmpegPath}` : "缺少 FFmpeg，导出会失败。");
});

async function handleUpload(req, res) {
  const originalName = decodeURIComponent(String(req.headers["x-file-name"] || "video"));
  const id = crypto.randomUUID();
  const ext = safeExtension(path.extname(originalName)) || ".video";
  const finalPath = path.join(uploadsDir, `${id}${ext}`);
  await streamToFile(req, finalPath);
  uploadedFiles.set(id, { id, path: finalPath, name: originalName });
  sendJson(res, { id, name: originalName });
}

async function handleExport(req, res) {
  if (!ffmpegPath) {
    sendJson(res, { error: "这台电脑还没有安装 FFmpeg，无法导出视频或音频。" }, 500);
    return;
  }
  if (!zipPath) {
    sendJson(res, { error: "这台电脑缺少 zip 命令，无法打包导出结果。" }, 500);
    return;
  }

  const { fileId, format, segments, outputDir } = await readJson(req);
  const source = uploadedFiles.get(fileId);
  if (!source) throw new Error("请先导入视频");
  if (!exportFormats.has(format)) throw new Error("不支持这个导出格式");
  if (!Array.isArray(segments) || segments.length === 0) throw new Error("请至少添加一个分段");

  const jobId = crypto.randomUUID();
  const customOutputDir = normalizeOutputDir(outputDir);
  const exportDir = customOutputDir ? path.join(customOutputDir, `segments-${jobId}`) : path.join(outputRoot, `export-${jobId}`);
  await fsp.mkdir(path.join(jobsDir, jobId), { recursive: true });
  await fsp.mkdir(exportDir, { recursive: true });

  const files = [];
  const usedNames = new Set();
  for (let index = 0; index < segments.length; index += 1) {
    const segment = normalizeSegment(segments[index], index);
    const outputName = `${segment.name}.${format}`;
    if (usedNames.has(outputName)) {
      throw new Error(`分段文件名重复：${outputName}`);
    }
    usedNames.add(outputName);
    const outputPath = path.join(exportDir, outputName);
    await runFfmpeg(source.path, outputPath, segment.start, segment.end, format);
    files.push(outputName);
  }

  const zipName = `segments-${jobId}.zip`;
  await runCommand(zipPath, ["-qr", path.join(outputRoot, zipName), "."], exportDir);
  sendJson(res, {
    folder: customOutputDir ? null : `/downloads/export-${jobId}/`,
    localFolder: customOutputDir ? exportDir : null,
    zip: `/downloads/${zipName}`,
    files
  });
}

async function handlePickFolder(res) {
  if (process.platform !== "darwin") {
    sendJson(res, { error: "当前系统不支持直接选择文件夹，请使用 ZIP 下载。" }, 400);
    return;
  }
  const script = 'POSIX path of (choose folder with prompt "选择分段导出文件夹")';
  const stdout = await runCommandWithOutput("osascript", ["-e", script], __dirname);
  sendJson(res, { path: stdout.trim() });
}

function normalizeSegment(segment, index) {
  const start = Number(segment.start);
  const end = Number(segment.end);
  if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end <= start) {
    throw new Error(`第 ${index + 1} 段时间不正确`);
  }
  const rawName = String(segment.name || `segment-${index + 1}`).trim();
  const name = safeFileName(rawName || `segment-${index + 1}`);
  return { start, end, name };
}

function runFfmpeg(inputPath, outputPath, start, end, format) {
  const args = ["-hide_banner", "-y", "-i", inputPath, "-ss", String(start), "-t", String(end - start)];
  if (format === "mp4") {
    args.push("-map", "0:v:0?", "-map", "0:a:0?", "-codec:v", "libx264", "-preset", "veryfast", "-crf", "20", "-codec:a", "aac", "-movflags", "+faststart");
  } else {
    args.push("-vn", ...audioArgs(format));
  }
  args.push(outputPath);
  return runCommand(ffmpegPath, args, __dirname);
}

function audioArgs(format) {
  return {
    mp3: ["-codec:a", "libmp3lame", "-q:a", "2"],
    wav: ["-codec:a", "pcm_s16le"],
    m4a: ["-codec:a", "aac", "-b:a", "192k"],
    aac: ["-codec:a", "aac", "-b:a", "192k"],
    flac: ["-codec:a", "flac"],
    ogg: ["-codec:a", "libvorbis", "-q:a", "5"]
  }[format];
}

function runCommand(command, args, cwd) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd });
    let stderr = "";
    child.stderr.on("data", chunk => {
      stderr += chunk.toString();
    });
    child.on("error", reject);
    child.on("close", code => {
      if (code === 0) resolve();
      else reject(new Error(stderr.split("\n").slice(-8).join("\n") || `命令执行失败：${code}`));
    });
  });
}

function runCommandWithOutput(command, args, cwd) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", chunk => {
      stdout += chunk.toString();
    });
    child.stderr.on("data", chunk => {
      stderr += chunk.toString();
    });
    child.on("error", reject);
    child.on("close", code => {
      if (code === 0) resolve(stdout);
      else reject(new Error(stderr.trim() || "选择文件夹失败"));
    });
  });
}

function normalizeOutputDir(outputDir) {
  const value = String(outputDir || "").trim();
  if (!value) return "";
  if (!path.isAbsolute(value)) throw new Error("导出文件夹路径不正确");
  return path.resolve(value);
}

async function findCommand(name) {
  const pathDirs = String(process.env.PATH || "")
    .split(path.delimiter)
    .filter(Boolean);
  const commonPaths = [path.join(__dirname, "work", "bin", name), `/opt/homebrew/bin/${name}`, `/usr/local/bin/${name}`, `/usr/bin/${name}`];
  const candidates = [...pathDirs.map(dir => path.join(dir, name)), ...commonPaths];
  const checked = new Set();
  for (const candidate of candidates) {
    if (checked.has(candidate)) continue;
    checked.add(candidate);
    try {
      await fsp.access(candidate, fs.constants.X_OK);
      return candidate;
    } catch {}
  }
  return null;
}

function streamToFile(stream, filePath) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(filePath);
    stream.pipe(output);
    stream.on("error", reject);
    output.on("error", reject);
    output.on("finish", resolve);
  });
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.setEncoding("utf8");
    req.on("data", chunk => {
      body += chunk;
      if (body.length > 1024 * 1024 * 2) reject(new Error("请求内容过大"));
    });
    req.on("end", () => {
      try {
        resolve(JSON.parse(body || "{}"));
      } catch {
        reject(new Error("请求格式不正确"));
      }
    });
    req.on("error", reject);
  });
}

async function serveFile(res, root, relativePath) {
  const target = path.resolve(root, relativePath);
  if (!target.startsWith(path.resolve(root))) {
    sendText(res, "Not found", 404);
    return;
  }
  const stat = await fsp.stat(target).catch(() => null);
  if (!stat) {
    sendText(res, "Not found", 404);
    return;
  }
  if (stat.isDirectory()) {
    const items = await fsp.readdir(target);
    sendText(res, items.map(item => `<a href="${encodeURIComponent(item)}">${item}</a>`).join("<br>"), 200, "text/html; charset=utf-8");
    return;
  }
  res.writeHead(200, { "Content-Type": contentType(target) });
  fs.createReadStream(target).pipe(res);
}

function sendJson(res, data, status = 200) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
}

function sendText(res, text, status = 200, type = "text/plain; charset=utf-8") {
  res.writeHead(status, { "Content-Type": type });
  res.end(text);
}

function safeFileName(name) {
  return name.replace(/[<>:"/\\|?*\u0000-\u001f]/g, "_").replace(/\s+/g, " ").slice(0, 120);
}

function safeExtension(ext) {
  return ext.replace(/[^a-zA-Z0-9.]/g, "").slice(0, 12);
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".zip": "application/zip",
    ".mp4": "video/mp4",
    ".mp3": "audio/mpeg",
    ".wav": "audio/wav",
    ".m4a": "audio/mp4",
    ".aac": "audio/aac",
    ".flac": "audio/flac",
    ".ogg": "audio/ogg"
  }[ext] || "application/octet-stream";
}
