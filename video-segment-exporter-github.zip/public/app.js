const videoInput = document.querySelector("#videoInput");
const preview = document.querySelector("#preview");
const addSegmentButton = document.querySelector("#addSegment");
const markStartButton = document.querySelector("#markStart");
const markEndButton = document.querySelector("#markEnd");
const bulkRenameButton = document.querySelector("#bulkRename");
const pickFolderButton = document.querySelector("#pickFolder");
const exportButton = document.querySelector("#exportSegments");
const renamePrefix = document.querySelector("#renamePrefix");
const formatSelect = document.querySelector("#format");
const segmentList = document.querySelector("#segmentList");
const statusBox = document.querySelector("#status");
const template = document.querySelector("#segmentTemplate");
const defaultSegmentDuration = 10;

let fileId = null;
let pendingStart = 0;
let pendingEnd = 0;
let activeNamePrefix = "segment";
let selectedOutputDir = "";
let previewEndTime = null;

videoInput.addEventListener("change", async () => {
  const file = videoInput.files?.[0];
  if (!file) return;

  preview.src = URL.createObjectURL(file);
  setStatus("正在导入视频...");

  const response = await fetch("/api/upload", {
    method: "POST",
    headers: { "X-File-Name": encodeURIComponent(file.name) },
    body: file
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "导入失败");

  fileId = result.id;
  segmentList.innerHTML = "";
  activeNamePrefix = renamePrefix.value.trim() || "segment";
  addSegment(0, defaultSegmentDuration, nextName());
  setStatus(`已导入：${result.name}`);
});

fetch("/api/health")
  .then(response => response.json())
  .then(result => {
    if (!result.ffmpegReady) {
      setStatus("提示：这台电脑还没有安装 FFmpeg，导出 MP4/MP3 前需要先安装。");
    }
  })
  .catch(() => {});

markStartButton.addEventListener("click", () => {
  pendingStart = roundTime(preview.currentTime);
  setStatus(`开始时间：${formatTime(pendingStart)}`);
});

markEndButton.addEventListener("click", () => {
  pendingEnd = roundTime(preview.currentTime);
  setStatus(`结束时间：${formatTime(pendingEnd)}`);
});

preview.addEventListener("timeupdate", () => {
  if (previewEndTime !== null && preview.currentTime >= previewEndTime) {
    preview.pause();
    previewEndTime = null;
  }
});

addSegmentButton.addEventListener("click", () => {
  const previousEnd = getPreviousSegmentEnd();
  const start = previousEnd ?? (pendingStart || roundTime(preview.currentTime));
  const end = pendingEnd > start ? pendingEnd : roundTime(start + defaultSegmentDuration);
  addSegment(start, end, nextName());
});

bulkRenameButton.addEventListener("click", () => {
  activeNamePrefix = renamePrefix.value.trim() || "segment";
  getRows().forEach((row, index) => {
    row.querySelector(".name").value = buildName(activeNamePrefix, index + 1);
  });
});

pickFolderButton.addEventListener("click", async () => {
  setStatus("正在打开文件夹选择...");
  try {
    const response = await fetch("/api/pick-folder", { method: "POST" });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "选择文件夹失败");
    selectedOutputDir = result.path;
    setStatus(`已选择导出文件夹：${result.path}`);
  } catch (error) {
    setStatus(error.message);
  }
});

exportButton.addEventListener("click", async () => {
  if (!fileId) {
    setStatus("请先导入视频。");
    return;
  }

  const segments = getSegments();
  if (segments.length === 0) {
    setStatus("请至少添加一个分段。");
    return;
  }

  setStatus("正在导出，请稍等...");
  exportButton.disabled = true;
  exportButton.textContent = "导出中...";
  try {
    const response = await fetch("/api/export", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fileId, format: formatSelect.value, segments, outputDir: selectedOutputDir })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "导出失败");
    if (result.localFolder) {
      setStatus(`导出完成：已保存到 ${result.localFolder}。也可 <a href="${result.zip}">下载 ZIP</a>。`);
    } else {
      setStatus(`导出完成：<a href="${result.zip}">下载 ZIP</a>，或打开 <a href="${result.folder}">分段文件夹</a>。`);
    }
  } catch (error) {
    setStatus(error.message);
  } finally {
    exportButton.disabled = false;
    exportButton.textContent = "批量导出";
  }
});

function addSegment(start, end, name) {
  const node = template.content.firstElementChild.cloneNode(true);
  node.querySelector(".name").value = name;
  node.querySelector(".start").value = formatTime(start);
  node.querySelector(".end").value = formatTime(end);
  node.querySelector(".listen").addEventListener("click", () => listenSegment(node));
  node.querySelector(".delete").addEventListener("click", () => node.remove());
  segmentList.prepend(node);
  segmentList.scrollTop = 0;
}

function getRows() {
  return [...segmentList.querySelectorAll(".segment-row")];
}

function getSegments() {
  return getRows()
    .map(row => ({
      name: row.querySelector(".name").value,
      start: parseTime(row.querySelector(".start").value),
      end: parseTime(row.querySelector(".end").value)
    }))
    .sort((first, second) => first.start - second.start);
}

function nextName() {
  return buildName(activeNamePrefix, getRows().length + 1);
}

function buildName(prefix, index) {
  return `${prefix}${String(index).padStart(2, "0")}`;
}

function getPreviousSegmentEnd() {
  const rows = getRows();
  if (rows.length === 0) return null;
  const end = parseTime(rows[0].querySelector(".end").value);
  return Number.isFinite(end) ? end : null;
}

function roundTime(value) {
  return Math.max(0, Math.round(value));
}

function formatTime(value) {
  return formatClock(value);
}

function formatClock(value) {
  const total = roundTime(value);
  const minutes = Math.floor(total / 60);
  const seconds = total - minutes * 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function parseTime(value) {
  const raw = String(value).trim();
  if (!raw) return Number.NaN;
  const parts = raw.split(":").map(part => Number(part));
  if (parts.some(part => !Number.isFinite(part) || part < 0)) return Number.NaN;
  if (parts.length === 1) return roundTime(parts[0]);
  if (parts.length === 2) return roundTime(parts[0] * 60 + parts[1]);
  if (parts.length === 3) return roundTime(parts[0] * 3600 + parts[1] * 60 + parts[2]);
  return Number.NaN;
}

async function listenSegment(row) {
  const start = parseTime(row.querySelector(".start").value);
  const end = parseTime(row.querySelector(".end").value);
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) {
    setStatus("当前分段时间不正确，无法试听。");
    return;
  }
  previewEndTime = end;
  preview.currentTime = start;
  await preview.play();
}

function setStatus(message) {
  statusBox.innerHTML = message;
}
