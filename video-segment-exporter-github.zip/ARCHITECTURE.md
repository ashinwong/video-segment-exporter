# 架构说明

## 文件职责

- `server.js`：提供本地网页服务、视频上传、分段导出和 ZIP 打包，不依赖 npm 包。
- `public/index.html`：工具主界面。
- `public/styles.css`：界面样式。
- `public/app.js`：前端交互，负责导入、分段、重命名和发起导出。
- `work/uploads/`：临时保存导入的视频。
- `outputs/`：保存导出的分段文件和 ZIP。

## 调用关系

浏览器页面上传视频到 `server.js`，导出时把分段信息发给 `server.js`，服务端调用 FFmpeg 生成 MP4 或 MP3，再打包为 ZIP。

## 关键决定

使用本地处理服务调用系统 FFmpeg 完成导出，原因是浏览器原生能力不能稳定导出 MP4 和 MP3。当前环境网络不可用，因此不引入 npm 依赖。
